package com.main.TaskManagement.enums;

public enum UserRole  {

    ADMIN,EMPLOYEE
}
